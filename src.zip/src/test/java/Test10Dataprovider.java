import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Test10Dataprovider {
	@DataProvider
	public Object[][] databank() {
		Object[][] obj=new Object[2][2];
		obj[0][0]="yogesh";
		obj[0][1]="12345";
		obj[1][0]="superman";
		obj[1][1]="547895";
		return obj;
	}
	
	@Test(dataProvider="databank")
	public void fbdata(String username,String password) {
		
		System.out.println(username+" "+password);
		
	}
	@DataProvider
	public  Object[][] instadata() {
		Object[][] instadata= {{"odifdo","12322"},{"gidsoa","75846"}};
		return instadata;
	
	}
	@Test(dataProvider="instadata")
	public void receivedata(String username,String password) {
		
		System.out.println(username+" "+password);
		
	}
	
	
	
	
	
	
	
	

}
