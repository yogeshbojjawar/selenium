import org.testng.annotations.Test;




//****testng runs the program by alphabetical order


public class Testng1 {
@Test
public void verify() {
	System.out.println("first testng program");	
}
@Test
public void login() {
	System.out.println("second testng program");	
}
@Test
public void signout() {
	System.out.println("third testng program");	
}









}
