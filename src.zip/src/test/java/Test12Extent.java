
public class Test12Extent {

}
